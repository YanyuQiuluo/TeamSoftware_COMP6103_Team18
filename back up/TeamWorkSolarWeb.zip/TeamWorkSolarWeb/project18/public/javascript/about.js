'use strict';
$('#donate').on('click', function () {
    window.location.href='http://localhost:3000/countrylistPage'
})