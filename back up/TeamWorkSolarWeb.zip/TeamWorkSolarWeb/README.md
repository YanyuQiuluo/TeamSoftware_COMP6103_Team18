Team 18 : Sunlight  
Project name : Solar Offset  
Team members : Guo Yifei, Li Zeyu, Wang Yixiang, Zhou Yue, Alfitni Arwa  
Client name : Andy Stratton  
